/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package quanlyphonggym;

import quanlyphonggym.UI.AuthUI.LoginUI;

/**
 *
 * @author nguyenduc
 */
public class Quanlyphonggym {

    public static void main(String[] args) {
        LoginUI loginUI = new LoginUI();
        loginUI.setVisible(true);
//        System.out.println("Hello World!");
    }
}
