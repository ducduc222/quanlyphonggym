package quanlyphonggym.Models;

public class NhanVienPhongTap {
    private int id;
    private int idPhongTap;
    private int idNhanVien;
    public NhanVienPhongTap() {
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getIdPhongTap() {
        return idPhongTap;
    }
    public void setIdPhongTap(int idPhongTap) {
        this.idPhongTap = idPhongTap;
    }
    public int getIdNhanVien() {
        return idNhanVien;
    }
    public void setIdNhanVien(int idNhanVien) {
        this.idNhanVien = idNhanVien;
    }

    
}
