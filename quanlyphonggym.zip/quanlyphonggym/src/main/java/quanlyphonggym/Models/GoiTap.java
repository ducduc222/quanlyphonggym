package quanlyphonggym.Models;

public class GoiTap {
    private int id;
    private String tenGoiTap;
    private String noiDungHinhThuc;
    private int soTien;
    public GoiTap() {
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getTenGoiTap() {
        return tenGoiTap;
    }
    public void setTenGoiTap(String tenGoiTap) {
        this.tenGoiTap = tenGoiTap;
    }
    public String getNoiDungHinhThuc() {
        return noiDungHinhThuc;
    }
    public void setNoiDungHinhThuc(String noiDungHinhThuc) {
        this.noiDungHinhThuc = noiDungHinhThuc;
    }
    public int getSoTien() {
        return soTien;
    }
    public void setSoTien(int soTien) {
        this.soTien = soTien;
    }
    
}
