package quanlyphonggym.Models;

public class LichSu {
    private int id;
    private int idHoiVien;
    private String gioVao;
    private String gioRa;
    private String ngaySuDung;
    
    public LichSu() {
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getIdHoiVien() {
        return idHoiVien;
    }
    public void setIdHoiVien(int idHoiVien) {
        this.idHoiVien = idHoiVien;
    }
    public String getGioVao() {
        return gioVao;
    }
    public void setGioVao(String gioVao) {
        this.gioVao = gioVao;
    }
    public String getGioRa() {
        return gioRa;
    }
    public void setGioRa(String gioRa) {
        this.gioRa = gioRa;
    }
    public String getNgaySuDung() {
        return ngaySuDung;
    }
    public void setNgaySuDung(String ngaySuDung) {
        this.ngaySuDung = ngaySuDung;
    }

    
}
