package quanlyphonggym.Models;

public class HoiVien {
    private int id;
    private String maHoiVien;
    private String hoTen;
    private String ngaySinh;
    private String gioiTinh;
    private String ngheNghiep;
    private String diaChi;
    private String soDienThoai;
    private String loaiThanhVien;
    private String maVanTay;
    public HoiVien() {
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getMaHoiVien() {
        return maHoiVien;
    }
    public void setMaHoiVien(String maHoiVien) {
        this.maHoiVien = maHoiVien;
    }
    public String getHoTen() {
        return hoTen;
    }
    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }
    public String getNgaySinh() {
        return ngaySinh;
    }
    public void setNgaySinh(String ngaySinh) {
        this.ngaySinh = ngaySinh;
    }
    public String getGioiTinh() {
        return gioiTinh;
    }
    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }
    public String getNgheNghiep() {
        return ngheNghiep;
    }
    public void setNgheNghiep(String ngheNghiep) {
        this.ngheNghiep = ngheNghiep;
    }
    public String getDiaChi() {
        return diaChi;
    }
    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }
    public String getSoDienThoai() {
        return soDienThoai;
    }
    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }
    public String getLoaiThanhVien() {
        return loaiThanhVien;
    }
    public void setLoaiThanhVien(String loaiThanhVien) {
        this.loaiThanhVien = loaiThanhVien;
    }
    public String getMaVanTay() {
        return maVanTay;
    }
    public void setMaVanTay(String maVanTay) {
        this.maVanTay = maVanTay;
    }

    
}
