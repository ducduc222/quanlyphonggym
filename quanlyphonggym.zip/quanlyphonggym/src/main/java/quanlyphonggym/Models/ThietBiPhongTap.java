package quanlyphonggym.Models;

public class ThietBiPhongTap {
    private int id;
    private String maThietBi;
    private String tenThietBi;
    private int soLuong;
    private String ngayNhap;
    private String ngayBaoHanh;
    private String xuatXu;
    private String tinhTrang;
    private int idPhongTap;
    public ThietBiPhongTap() {
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getMaThietBi() {
        return maThietBi;
    }
    public void setMaThietBi(String maThietBi) {
        this.maThietBi = maThietBi;
    }
    public String getTenThietBi() {
        return tenThietBi;
    }
    public void setTenThietBi(String tenThietBi) {
        this.tenThietBi = tenThietBi;
    }
    public int getSoLuong() {
        return soLuong;
    }
    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }
    public String getNgayNhap() {
        return ngayNhap;
    }
    public void setNgayNhap(String ngayNhap) {
        this.ngayNhap = ngayNhap;
    }
    public String getNgayBaoHanh() {
        return ngayBaoHanh;
    }
    public void setNgayBaoHanh(String ngayBaoHanh) {
        this.ngayBaoHanh = ngayBaoHanh;
    }
    public String getXuatXu() {
        return xuatXu;
    }
    public void setXuatXu(String xuatXu) {
        this.xuatXu = xuatXu;
    }
    public String getTinhTrang() {
        return tinhTrang;
    }
    public void setTinhTrang(String tinhTrang) {
        this.tinhTrang = tinhTrang;
    }
    public int getIdPhongTap() {
        return idPhongTap;
    }
    public void setIdPhongTap(int idPhongTap) {
        this.idPhongTap = idPhongTap;
    }
    
}
