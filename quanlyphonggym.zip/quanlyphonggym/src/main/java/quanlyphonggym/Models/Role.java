package quanlyphonggym.Models;

public class Role {
    private int id;
    private String tenRole;
    public Role() {
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getTenRole() {
        return tenRole;
    }
    public void setTenRole(String tenRole) {
        this.tenRole = tenRole;
    }

    
}
