package quanlyphonggym.Models;

public class PTHoiVien {

    private int id;
    private int idNhanVien;
    private int idHoiVien;
    public PTHoiVien() {
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getIdNhanVien() {
        return idNhanVien;
    }
    public void setIdNhanVien(int idNhanVien) {
        this.idNhanVien = idNhanVien;
    }
    public int getIdHoiVien() {
        return idHoiVien;
    }
    public void setIdHoiVien(int idHoiVien) {
        this.idHoiVien = idHoiVien;
    }
    
}
